/**
 * Exercício 6:
 * Refatore este algoritmo de verificação de senha,
 * removendo todos os números mágicos e usando constantes significativas.
 */

// function validarSenha(senha) {
//   if (senha.length < 8) {
//     return {
//       valida: false,
//       mensagem: "Senha muito curta",
//     };
//   }

//   let pontuacao = 0;

//   if (senha.length >= 12) {
//     pontuacao += 2;
//   } else if (senha.length >= 10) {
//     pontuacao += 1;
//   }

//   if (/[A-Z]/.test(senha)) {
//     pontuacao += 2;
//   }
//   if (/[a-z]/.test(senha)) {
//     pontuacao += 2;
//   }
//   if (/[0-9]/.test(senha)) {
//     pontuacao += 2;
//   }
//   if (/[^A-Za-z0-9]/.test(senha)) {
//     pontuacao += 3;
//   }

//   if (pontuacao < 5) {
//     return { valida: false, mensagem: "Senha fraca" };
//   }
//   if (pontuacao < 8) {
//     return { valida: true, mensagem: "Senha média" };
//   }

//   return {
//     valida: true,
//     mensagem: "Senha forte",
//   };
// }

function validarSenha(senha) {
  const MIN_TAMANHO_SENHA = 8;
  const TAMANHO_SENHA_MEDIO = 10;
  const TAMANHO_SENHA_FORTE = 12;

  const PONTUACAO_MINIMA = 5;
  const PONTUACAO_MEDIA = 8;

  const PONTUACAO_LETRA_MAIUSCULA = 2;
  const PONTUACAO_LETRA_MINUSCULA = 2;
  const PONTUACAO_NUMERO = 2;
  const PONTUACAO_SIMBOLO = 3;

  if (senha.length < MIN_TAMANHO_SENHA) {
    return {
      valida: false,
      mensagem: "Senha muito curta",
    };
  }

  let pontuacao = 0;

  if (senha.length >= TAMANHO_SENHA_FORTE) {
    pontuacao += PONTUACAO_FORTE;
  } else if (senha.length >= TAMANHO_SENHA_MEDIO) {
    pontuacao += PONTUACAO_MEDIA;
  }

  if (/[A-Z]/.test(senha)) {
    pontuacao += PONTUACAO_LETRA_MAIUSCULA;
  }
  if (/[a-z]/.test(senha)) {
    pontuacao += PONTUACAO_LETRA_MINUSCULA;
  }
  if (/[0-9]/.test(senha)) {
    pontuacao += PONTUACAO_NUMERO;
  }
  if (/[^A-Za-z0-9]/.test(senha)) {
    pontuacao += PONTUACAO_SIMBOLO;
  }

  if (pontuacao < PONTUACAO_MINIMA) {
    return { valida: false, mensagem: "Senha fraca" };
  }
  if (pontuacao < PONTUACAO_MEDIA) {
    return { valida: true, mensagem: "Senha média" };
  }

  return {
    valida: true,
    mensagem: "Senha forte",
  };
}


